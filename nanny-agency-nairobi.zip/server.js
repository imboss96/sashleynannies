import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const port = Number(process.env.PORT) || 3000;
const publicDirectory = fileURLToPath(new URL('.', import.meta.url));

const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
};

const getFilePath = (requestUrl) => {
  const pathname = new URL(requestUrl, 'http://localhost').pathname;
  const requestedPath = pathname === '/' ? '/index.html' : pathname === '/contact' ? '/contact.html' : pathname;
  const filePath = normalize(join(publicDirectory, requestedPath));

  return filePath.startsWith(publicDirectory) ? filePath : null;
};

const server = createServer((request, response) => {
  if (request.url === '/health' && request.method === 'GET') {
    response.writeHead(200, { 'Content-Type': 'application/json' });
    response.end(JSON.stringify({ status: 'ok' }));
    return;
  }

  if (request.method !== 'GET') {
    response.writeHead(405, { 'Content-Type': 'application/json; charset=utf-8' });
    response.end(JSON.stringify({ error: 'Method not allowed' }));
    return;
  }

  const filePath = getFilePath(request.url);

  if (!filePath) {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('Not found');
    return;
  }

  stat(filePath)
    .then(() => {
      response.writeHead(200, {
        'Content-Type': contentTypes[extname(filePath)] || 'application/octet-stream',
      });
      createReadStream(filePath).pipe(response);
    })
    .catch(() => {
      response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end('Not found');
    });
});

server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
