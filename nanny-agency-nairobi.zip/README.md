# Sashleyweb Static Website

Static Sashley Nannies website. Upload the HTML, CSS, JavaScript, image and `.htaccess` files to your web host's public folder.

## Pages

- `/` serves `index.html`.
- `/contact` serves `contact.html` through the Apache rewrite rule in `.htaccess`.
- `/privacy.html` and `/terms.html` serve the legal pages.
