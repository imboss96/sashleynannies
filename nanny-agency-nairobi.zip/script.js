document.addEventListener('DOMContentLoaded', () => {
  const faqQuestions = document.querySelectorAll('.faq-question');

  faqQuestions.forEach(button => {
    button.addEventListener('click', (e) => {
      e.preventDefault();
      const faqItem = button.parentElement;

      // Close all other open FAQ accordions
      document.querySelectorAll('.faq-item').forEach(item => {
        if (item !== faqItem) {
          item.classList.remove('active');
        }
      });

      // Toggle the clicked FAQ accordion
      faqItem.classList.toggle('active');
    });
  });
});

